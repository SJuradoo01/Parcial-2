#include "../include/Medico.h"
#include <iostream>

Medico::Medico(const string &id, const string &nombre, const string &especialidad, int aniosExperiencia)
    : Personal(id, nombre, especialidad), aniosExperiencia(aniosExperiencia) {}

Medico::~Medico() {}

void Medico::ejecutarAccion() {
    cout << "  -> Medico " << nombre << ": Estabilizando signos vitales." << endl;
}

void Medico::mostrarInfo() const {
    Personal::mostrarInfo();
    cout << " | Tipo: Medico (" << aniosExperiencia << " anios exp.)" << endl;
}
