#include "../include/Mision.h"
#include <iostream>

Mision::Mision(const string &id, const string &nombre, const string &ubicacion)
    : id(id), nombre(nombre), ubicacion(ubicacion), numRecursos(0), capacidadRecursos(4) {
    recursosAsignados = new Recurso*[capacidadRecursos];
}

Mision::~Mision() {
    // Solo se libera el arreglo de punteros. Los objetos Recurso apuntados
    // pertenecen al Controlador y se liberan una unica vez alli (evita double free).
    delete[] recursosAsignados;
}

void Mision::redimensionar() {
    int nuevaCapacidad = capacidadRecursos * 2;
    Recurso **nuevoArreglo = new Recurso*[nuevaCapacidad];

    for (int i = 0; i < numRecursos; i++) {
        nuevoArreglo[i] = recursosAsignados[i];
    }

    delete[] recursosAsignados;
    recursosAsignados = nuevoArreglo;
    capacidadRecursos = nuevaCapacidad;
}

void Mision::asignarRecurso(Recurso *recurso) {
    if (recurso == nullptr) return;

    if (numRecursos == capacidadRecursos) {
        redimensionar();
    }

    recursosAsignados[numRecursos] = recurso;
    numRecursos++;
    recurso->setDisponible(false);
}

void Mision::ejecutarMision() {
    cout << "\n=== Ejecutando mision: " << nombre << " (" << ubicacion << ") ===" << endl;
    if (numRecursos == 0) {
        cout << "  (No hay recursos asignados a esta mision)" << endl;
        return;
    }

    // Polimorfismo: cada recurso ejecuta su propia version de ejecutarAccion() (HU03)
    for (int i = 0; i < numRecursos; i++) {
        recursosAsignados[i]->ejecutarAccion();
    }
}

void Mision::mostrarInfo() const {
    cout << "Mision [" << id << "] " << nombre
         << " | Ubicacion: " << ubicacion
         << " | Recursos asignados: " << numRecursos << endl;
}

string Mision::getId() const { return id; }
string Mision::getNombre() const { return nombre; }
int Mision::getNumRecursos() const { return numRecursos; }
