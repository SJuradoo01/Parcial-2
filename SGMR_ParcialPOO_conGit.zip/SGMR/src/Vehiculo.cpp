#include "../include/Vehiculo.h"
#include <iostream>

Vehiculo::Vehiculo(const string &id, const string &nombre, const string &placa, int capacidad)
    : Recurso(id, nombre), placa(placa), capacidad(capacidad) {}

Vehiculo::~Vehiculo() {}

void Vehiculo::mostrarInfo() const {
    Recurso::mostrarInfo();
    cout << " | Placa: " << placa << " | Capacidad: " << capacidad;
}

string Vehiculo::getPlaca() const { return placa; }
int Vehiculo::getCapacidad() const { return capacidad; }
