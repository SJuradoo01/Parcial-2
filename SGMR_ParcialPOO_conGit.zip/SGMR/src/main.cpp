#include "../include/Controlador.h"

/*
 * HU04: main.cpp unicamente instancia el Controlador e invoca su metodo de inicio.
 * Toda la logica del sistema se delega a la clase Controlador y a las clases
 * que esta administra.
 */
int main() {
    Controlador controlador;
    controlador.iniciar();
    return 0;
}
