#include "../include/Helicoptero.h"
#include <iostream>

Helicoptero::Helicoptero(const string &id, const string &nombre, const string &placa,
                          int capacidad, double altitudMaxima)
    : Vehiculo(id, nombre, placa, capacidad), altitudMaxima(altitudMaxima) {}

Helicoptero::~Helicoptero() {}

void Helicoptero::ejecutarAccion() {
    cout << "  -> Helicoptero " << nombre << ": Realizando extraccion aerea." << endl;
}

void Helicoptero::mostrarInfo() const {
    Vehiculo::mostrarInfo();
    cout << " | Tipo: Helicoptero (Altitud max: " << altitudMaxima << "m)" << endl;
}
