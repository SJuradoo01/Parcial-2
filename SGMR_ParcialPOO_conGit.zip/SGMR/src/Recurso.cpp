#include "../include/Recurso.h"
#include <iostream>

Recurso::Recurso(const string &id, const string &nombre)
    : id(id), nombre(nombre), disponible(true) {}

Recurso::~Recurso() {
    // Destructor virtual vacio: permite liberar correctamente objetos derivados
    // cuando se elimina un Recurso* que en realidad apunta a una subclase (HT02).
}

void Recurso::mostrarInfo() const {
    cout << "[Recurso] ID: " << id
         << " | Nombre: " << nombre
         << " | Disponible: " << (disponible ? "Si" : "No");
}

string Recurso::getId() const { return id; }
string Recurso::getNombre() const { return nombre; }
bool Recurso::getDisponible() const { return disponible; }
void Recurso::setDisponible(bool valor) { disponible = valor; }
