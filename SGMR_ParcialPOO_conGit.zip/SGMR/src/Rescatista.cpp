#include "../include/Rescatista.h"
#include <iostream>

Rescatista::Rescatista(const string &id, const string &nombre, const string &especialidad,
                        const string &equipoRescate)
    : Personal(id, nombre, especialidad), equipoRescate(equipoRescate) {}

Rescatista::~Rescatista() {}

void Rescatista::ejecutarAccion() {
    cout << "  -> Rescatista " << nombre << ": Buscando sobrevivientes en escombros." << endl;
}

void Rescatista::mostrarInfo() const {
    Personal::mostrarInfo();
    cout << " | Tipo: Rescatista (Equipo: " << equipoRescate << ")" << endl;
}
