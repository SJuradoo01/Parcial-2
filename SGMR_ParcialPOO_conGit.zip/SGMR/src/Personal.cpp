#include "../include/Personal.h"
#include <iostream>

Personal::Personal(const string &id, const string &nombre, const string &especialidad)
    : Recurso(id, nombre), especialidad(especialidad) {}

Personal::~Personal() {}

void Personal::mostrarInfo() const {
    Recurso::mostrarInfo();
    cout << " | Especialidad: " << especialidad;
}

string Personal::getEspecialidad() const { return especialidad; }
