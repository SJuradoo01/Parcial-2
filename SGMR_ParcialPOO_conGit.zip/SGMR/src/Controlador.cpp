#include "../include/Controlador.h"
#include "../include/Ambulancia.h"
#include "../include/Helicoptero.h"
#include "../include/Medico.h"
#include "../include/Rescatista.h"
#include <iostream>
#include <limits>

Controlador::Controlador()
    : numRecursos(0), capacidadRecursos(4), numMisiones(0), capacidadMisiones(4) {
    listaRecursos = new Recurso*[capacidadRecursos];
    listaMisiones = new Mision*[capacidadMisiones];
    cargarDatosPrueba();
}

Controlador::~Controlador() {
    // HT02: liberacion completa de toda la memoria dinamica del sistema.
    for (int i = 0; i < numRecursos; i++) {
        delete listaRecursos[i]; // llama al destructor virtual correcto (polimorfismo)
    }
    delete[] listaRecursos;

    for (int i = 0; i < numMisiones; i++) {
        delete listaMisiones[i];
    }
    delete[] listaMisiones;

    cout << "\n[Controlador] Memoria liberada correctamente. Hasta pronto." << endl;
}

void Controlador::redimensionarRecursos() {
    int nuevaCapacidad = capacidadRecursos * 2;
    Recurso **nuevoArreglo = new Recurso*[nuevaCapacidad];
    for (int i = 0; i < numRecursos; i++) nuevoArreglo[i] = listaRecursos[i];
    delete[] listaRecursos;
    listaRecursos = nuevoArreglo;
    capacidadRecursos = nuevaCapacidad;
}

void Controlador::redimensionarMisiones() {
    int nuevaCapacidad = capacidadMisiones * 2;
    Mision **nuevoArreglo = new Mision*[nuevaCapacidad];
    for (int i = 0; i < numMisiones; i++) nuevoArreglo[i] = listaMisiones[i];
    delete[] listaMisiones;
    listaMisiones = nuevoArreglo;
    capacidadMisiones = nuevaCapacidad;
}

void Controlador::cargarDatosPrueba() {
    // HU05: datos quemados, listos para pruebas de asignacion y ejecucion.
    // Se redimensiona el arreglo dinamico manualmente cada vez que se llena
    // antes de insertar, para no desbordar la memoria reservada (HT01).
    if (numRecursos == capacidadRecursos) redimensionarRecursos();
    listaRecursos[numRecursos++] = new Ambulancia("AMB-01", "Ambulancia Cruz Roja 1", "VAL-101", 2, "Avanzado");

    if (numRecursos == capacidadRecursos) redimensionarRecursos();
    listaRecursos[numRecursos++] = new Ambulancia("AMB-02", "Ambulancia Cruz Roja 2", "VAL-102", 2, "Basico");

    if (numRecursos == capacidadRecursos) redimensionarRecursos();
    listaRecursos[numRecursos++] = new Helicoptero("HEL-01", "Halcon 1", "HEL-900", 4, 3000.0);

    if (numRecursos == capacidadRecursos) redimensionarRecursos();
    listaRecursos[numRecursos++] = new Medico("MED-01", "Dra. Ana Torres", "Urgencias", 8);

    if (numRecursos == capacidadRecursos) redimensionarRecursos();
    listaRecursos[numRecursos++] = new Medico("MED-02", "Dr. Luis Peña", "Trauma", 5);

    if (numRecursos == capacidadRecursos) redimensionarRecursos();
    listaRecursos[numRecursos++] = new Rescatista("RES-01", "Carlos Diaz", "Rescate en altura", "Cuerdas y poleas");

    if (numRecursos == capacidadRecursos) redimensionarRecursos();
    listaRecursos[numRecursos++] = new Rescatista("RES-02", "Marta Gomez", "Busqueda K9", "Perros de busqueda");

    Mision *m1 = new Mision("MIS-01", "Deslizamiento Via al Mar", "Km 18, Via al Mar");
    if (numMisiones == capacidadMisiones) redimensionarMisiones();
    listaMisiones[numMisiones++] = m1;

    Mision *m2 = new Mision("MIS-02", "Inundacion Aguablanca", "Distrito de Aguablanca, Cali");
    if (numMisiones == capacidadMisiones) redimensionarMisiones();
    listaMisiones[numMisiones++] = m2;

    cout << "[Controlador] Datos de prueba cargados: " << numRecursos
         << " recursos y " << numMisiones << " misiones." << endl;
}

void Controlador::verRecursos() const {
    cout << "\n--- Recursos registrados (" << numRecursos << ") ---" << endl;
    if (numRecursos == 0) {
        cout << "No hay recursos registrados." << endl;
        return;
    }
    for (int i = 0; i < numRecursos; i++) {
        cout << i + 1 << ". ";
        listaRecursos[i]->mostrarInfo(); // polimorfismo en la salida (ya incluye salto de linea)
    }

    cout << "\n--- Misiones registradas (" << numMisiones << ") ---" << endl;
    for (int i = 0; i < numMisiones; i++) {
        cout << i + 1 << ". ";
        listaMisiones[i]->mostrarInfo();
    }
}

void Controlador::registrarRecurso() {
    if (numRecursos == capacidadRecursos) {
        redimensionarRecursos();
    }

    cout << "\n--- Registrar nuevo recurso ---" << endl;
    cout << "Tipos disponibles: 1. Ambulancia  2. Helicoptero  3. Medico  4. Rescatista" << endl;
    cout << "Seleccione el tipo: ";
    int tipo;
    cin >> tipo;

    if (cin.fail()) {
        cin.clear();
        cin.ignore(numeric_limits<streamsize>::max(), '\n');
        cout << "Entrada invalida." << endl;
        return;
    }

    string id, nombre;
    cout << "ID del recurso: ";
    cin >> id;
    cout << "Nombre: ";
    cin.ignore();
    getline(cin, nombre);

    Recurso *nuevo = nullptr;

    switch (tipo) {
        case 1: {
            string placa, tipoTraslado;
            int capacidad;
            cout << "Placa: ";
            cin >> placa;
            cout << "Capacidad: ";
            cin >> capacidad;
            cout << "Tipo de traslado (Basico/Avanzado): ";
            cin >> tipoTraslado;
            nuevo = new Ambulancia(id, nombre, placa, capacidad, tipoTraslado);
            break;
        }
        case 2: {
            string placa;
            int capacidad;
            double altitud;
            cout << "Placa: ";
            cin >> placa;
            cout << "Capacidad: ";
            cin >> capacidad;
            cout << "Altitud maxima (m): ";
            cin >> altitud;
            nuevo = new Helicoptero(id, nombre, placa, capacidad, altitud);
            break;
        }
        case 3: {
            string especialidad;
            int anios;
            cout << "Especialidad: ";
            cin.ignore();
            getline(cin, especialidad);
            cout << "Anios de experiencia: ";
            cin >> anios;
            nuevo = new Medico(id, nombre, especialidad, anios);
            break;
        }
        case 4: {
            string especialidad, equipo;
            cout << "Especialidad: ";
            cin.ignore();
            getline(cin, especialidad);
            cout << "Equipo de rescate: ";
            getline(cin, equipo);
            nuevo = new Rescatista(id, nombre, especialidad, equipo);
            break;
        }
        default:
            cout << "Tipo invalido." << endl;
            return;
    }

    listaRecursos[numRecursos++] = nuevo;
    cout << "Recurso registrado con exito." << endl;
}

void Controlador::crearMision() {
    if (numMisiones == capacidadMisiones) {
        redimensionarMisiones();
    }

    string id, nombre, ubicacion;
    cout << "\n--- Crear nueva mision ---" << endl;
    cout << "ID de la mision: ";
    cin >> id;
    cout << "Nombre: ";
    cin.ignore();
    getline(cin, nombre);
    cout << "Ubicacion: ";
    getline(cin, ubicacion);

    Mision *nueva = new Mision(id, nombre, ubicacion);
    listaMisiones[numMisiones++] = nueva;
    cout << "Mision creada con exito." << endl;
}

void Controlador::asignarRecursoAMision() {
    if (numMisiones == 0) {
        cout << "No hay misiones creadas. Cree una mision primero." << endl;
        return;
    }
    if (numRecursos == 0) {
        cout << "No hay recursos registrados." << endl;
        return;
    }

    verRecursos();

    cout << "\nSeleccione el numero de la mision: ";
    int idxMision;
    cin >> idxMision;
    Mision *mision = buscarMisionPorIndice(idxMision - 1);
    if (mision == nullptr) {
        cout << "Mision invalida." << endl;
        return;
    }

    cout << "Seleccione el numero del recurso a asignar: ";
    int idxRecurso;
    cin >> idxRecurso;
    Recurso *recurso = buscarRecursoDisponiblePorIndice(idxRecurso - 1);
    if (recurso == nullptr) {
        cout << "Recurso invalido." << endl;
        return;
    }

    // HU02: la mision almacena el recurso bajo el tipo generico Recurso* (polimorfismo)
    mision->asignarRecurso(recurso);
    cout << "Recurso asignado correctamente a la mision." << endl;
}

void Controlador::ejecutarMision() {
    if (numMisiones == 0) {
        cout << "No hay misiones registradas." << endl;
        return;
    }

    for (int i = 0; i < numMisiones; i++) {
        cout << i + 1 << ". ";
        listaMisiones[i]->mostrarInfo();
    }

    cout << "Seleccione el numero de la mision a ejecutar: ";
    int idx;
    cin >> idx;

    Mision *mision = buscarMisionPorIndice(idx - 1);
    if (mision == nullptr) {
        cout << "Mision invalida." << endl;
        return;
    }

    // HU03: recorrido polimorfico de los recursos de la mision
    mision->ejecutarMision();
}

Recurso* Controlador::buscarRecursoDisponiblePorIndice(int indice) const {
    if (indice < 0 || indice >= numRecursos) return nullptr;
    return listaRecursos[indice];
}

Mision* Controlador::buscarMisionPorIndice(int indice) const {
    if (indice < 0 || indice >= numMisiones) return nullptr;
    return listaMisiones[indice];
}

void Controlador::iniciar() {
    int opcion = -1;

    cout << "==========================================" << endl;
    cout << " Sistema de Gestion de Misiones de Rescate " << endl;
    cout << "==========================================" << endl;

    do {
        cout << "\n----- MENU PRINCIPAL -----" << endl;
        cout << "1. Ver recursos y misiones" << endl;
        cout << "2. Registrar recurso" << endl;
        cout << "3. Crear mision" << endl;
        cout << "4. Asignar recurso a mision" << endl;
        cout << "5. Ejecutar mision" << endl;
        cout << "6. Salir" << endl;
        cout << "Seleccione una opcion: ";

        cin >> opcion;

        if (cin.fail()) {
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
            cout << "Opcion invalida, intente de nuevo." << endl;
            continue;
        }

        switch (opcion) {
            case 1: verRecursos(); break;
            case 2: registrarRecurso(); break;
            case 3: crearMision(); break;
            case 4: asignarRecursoAMision(); break;
            case 5: ejecutarMision(); break;
            case 6: cout << "Cerrando el sistema..." << endl; break;
            default: cout << "Opcion invalida, intente de nuevo." << endl; break;
        }

    } while (opcion != 6);
}
