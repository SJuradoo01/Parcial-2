#include "../include/Ambulancia.h"
#include <iostream>

Ambulancia::Ambulancia(const string &id, const string &nombre, const string &placa,
                        int capacidad, const string &tipoTraslado)
    : Vehiculo(id, nombre, placa, capacidad), tipoTraslado(tipoTraslado) {}

Ambulancia::~Ambulancia() {}

void Ambulancia::ejecutarAccion() {
    cout << "  -> Ambulancia " << nombre << ": Transportando paciente via terrestre." << endl;
}

void Ambulancia::mostrarInfo() const {
    Vehiculo::mostrarInfo();
    cout << " | Tipo: Ambulancia (" << tipoTraslado << ")" << endl;
}
