#ifndef VEHICULO_H
#define VEHICULO_H

#include "Recurso.h"

/*
 * Clase intermedia que agrupa los recursos de tipo vehicular (terrestres y aereos).
 */
class Vehiculo : public Recurso {
protected:
    string placa;
    int capacidad;

public:
    Vehiculo(const string &id, const string &nombre, const string &placa, int capacidad);
    virtual ~Vehiculo();

    virtual void mostrarInfo() const;

    string getPlaca() const;
    int getCapacidad() const;
};

#endif
