#ifndef MEDICO_H
#define MEDICO_H

#include "Personal.h"

class Medico : public Personal {
private:
    int aniosExperiencia;

public:
    Medico(const string &id, const string &nombre, const string &especialidad, int aniosExperiencia);
    ~Medico();

    void ejecutarAccion();
    void mostrarInfo() const;
};

#endif
