#ifndef PERSONAL_H
#define PERSONAL_H

#include "Recurso.h"

/*
 * Clase intermedia que agrupa los recursos de tipo humano.
 */
class Personal : public Recurso {
protected:
    string especialidad;

public:
    Personal(const string &id, const string &nombre, const string &especialidad);
    virtual ~Personal();

    virtual void mostrarInfo() const;

    string getEspecialidad() const;
};

#endif
