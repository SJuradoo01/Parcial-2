#ifndef MISION_H
#define MISION_H

#include <string>
#include "Recurso.h"

using namespace std;

/*
 * Representa una mision de emergencia. Almacena punteros a Recurso (HU02),
 * tratando de forma generica vehiculos y personal, sin usar std::vector (HT01).
 * IMPORTANTE: Mision NO es duenia de los objetos Recurso (esos los administra
 * el Controlador); por eso su destructor solo libera el arreglo de punteros,
 * nunca los recursos en si, evitando doble liberacion (double free).
 */
class Mision {
private:
    string id;
    string nombre;
    string ubicacion;

    Recurso **recursosAsignados; // arreglo dinamico de punteros (HT01)
    int numRecursos;
    int capacidadRecursos;

    void redimensionar(); // duplica la capacidad interna cuando se llena

public:
    Mision(const string &id, const string &nombre, const string &ubicacion);
    ~Mision();

    void asignarRecurso(Recurso *recurso); // paso por puntero (HT03)
    void ejecutarMision();                 // recorre y ejecuta polimorficamente (HU03)
    void mostrarInfo() const;

    string getId() const;
    string getNombre() const;
    int getNumRecursos() const;
};

#endif
