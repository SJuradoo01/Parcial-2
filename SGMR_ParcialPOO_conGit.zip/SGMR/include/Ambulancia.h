#ifndef AMBULANCIA_H
#define AMBULANCIA_H

#include "Vehiculo.h"

class Ambulancia : public Vehiculo {
private:
    string tipoTraslado; // ej. "Basico", "Avanzado"

public:
    Ambulancia(const string &id, const string &nombre, const string &placa,
               int capacidad, const string &tipoTraslado);
    ~Ambulancia();

    void ejecutarAccion();
    void mostrarInfo() const;
};

#endif
