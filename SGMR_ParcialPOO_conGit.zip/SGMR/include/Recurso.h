#ifndef RECURSO_H
#define RECURSO_H

#include <string>

using namespace std;

/*
 * Clase base abstracta para todo recurso del sistema (vehiculos y personal).
 * Define la interfaz comun que permite el polimorfismo requerido en HU02 y HU03.
 */
class Recurso {
protected:
    string id;
    string nombre;
    bool disponible;

public:
    Recurso(const string &id, const string &nombre);
    virtual ~Recurso();

    // Metodo virtual puro: cada subclase define su propia accion operativa (HU03)
    virtual void ejecutarAccion() = 0;

    // Metodo virtual: cada subclase puede enriquecer la informacion mostrada
    virtual void mostrarInfo() const;

    string getId() const;
    string getNombre() const;
    bool getDisponible() const;
    void setDisponible(bool valor);
};

#endif
