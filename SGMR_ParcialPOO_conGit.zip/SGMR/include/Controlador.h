#ifndef CONTROLADOR_H
#define CONTROLADOR_H

#include "Recurso.h"
#include "Mision.h"

/*
 * Clase Controlador: unico punto de entrada de la logica del programa (HU04).
 * main.cpp solo instancia esta clase e invoca iniciar().
 * Administra las dos colecciones generales del sistema (recursos y misiones)
 * usando arreglos dinamicos de punteros (HT01), y es la unica responsable
 * de liberar esa memoria en su destructor (HT02).
 */
class Controlador {
private:
    Recurso **listaRecursos;
    int numRecursos;
    int capacidadRecursos;

    Mision **listaMisiones;
    int numMisiones;
    int capacidadMisiones;

    void redimensionarRecursos();
    void redimensionarMisiones();

    void cargarDatosPrueba(); // HU05: datos quemados al iniciar

    // Opciones del menu (HU04)
    void verRecursos() const;
    void registrarRecurso();
    void crearMision();
    void asignarRecursoAMision();
    void ejecutarMision();

    Recurso* buscarRecursoDisponiblePorIndice(int indice) const;
    Mision* buscarMisionPorIndice(int indice) const;

public:
    Controlador();
    ~Controlador();

    void iniciar(); // ciclo principal del menu
};

#endif
