#ifndef HELICOPTERO_H
#define HELICOPTERO_H

#include "Vehiculo.h"

class Helicoptero : public Vehiculo {
private:
    double altitudMaxima; // en metros

public:
    Helicoptero(const string &id, const string &nombre, const string &placa,
                int capacidad, double altitudMaxima);
    ~Helicoptero();

    void ejecutarAccion();
    void mostrarInfo() const;
};

#endif
