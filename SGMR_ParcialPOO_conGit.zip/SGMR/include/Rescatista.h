#ifndef RESCATISTA_H
#define RESCATISTA_H

#include "Personal.h"

class Rescatista : public Personal {
private:
    string equipoRescate; // ej. "Perros de busqueda", "Cuerdas y poleas"

public:
    Rescatista(const string &id, const string &nombre, const string &especialidad,
               const string &equipoRescate);
    ~Rescatista();

    void ejecutarAccion();
    void mostrarInfo() const;
};

#endif
